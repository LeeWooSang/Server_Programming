#pragma once
#include "targetver.h"

#include <stdio.h>
#include <tchar.h>

#include <iostream>
#include <stdlib.h>
#include <time.h>
#include <Windows.h>
#include <string>
#include <map>
using namespace std;

#define WIDTH 800
#define HEIGHT 800